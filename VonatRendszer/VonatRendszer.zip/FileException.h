#ifndef FILEEXCEPTION_H
#define FILEEXCEPTION_H

#include "memtrace.h"
#include <exception>
/**
* Ezeknek az oszt�lyoknak a seg�ts�g�vel vizsg�ljuk, hogy a f�jlunkat meg tudtuk-e nyitni, illetve a tartalm�nak l�t�t
**/
class FileNotFoundException : public std::exception {
public:
    const char* what() const throw() {
        return "Hiba a vonatok.txt fajl megnyitasa soran!";
    }
};

class EmptyFileException : public std::exception {
public:
    const char* what() const throw() {
        return "A fajl ures!";
    }
};

#endif // FILEEXCEPTION_H
